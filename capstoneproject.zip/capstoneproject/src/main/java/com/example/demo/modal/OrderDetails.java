package com.example.demo.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="OrderDetails")
public class OrderDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Order_id;

	@Column(name ="product_id")
	private String product_id;

	@Column(name ="Order_status")
	private String Order_status;

	@Column(name ="No_of_items")
	private int No_of_items;
	
	@Column(name ="Order_date")
	private String Order_date;
	
	@Column(name ="User_id")
	private String User_id;



	public OrderDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public OrderDetails(int Order_id, String product_id, String Order_status, int No_of_items, String Order_date, int User_id) {
		super();
		this.Order_id = Order_id;
		this.product_id = product_id;
		this.Order_status =  Order_status;
		this.No_of_items = No_of_items;
		this.Order_date = Order_date;
		
	}


	public int No_of_items() {
		return Order_id;
	}

	

	public String getproduct_id() {
		return product_id;
	}

	public void setproduct_id(String product_id) {
		this.product_id = product_id;
	}

	public String getOrder_status() {
		return Order_status;
	}

	public void setOrder_status(String Order_status) {
		this.Order_status = Order_status;
	}

	public int getNo_of_items() {
		return No_of_items;
	}

	public void setNo_of_items(int No_of_items) {
		this.No_of_items = No_of_items;
	}
    
	
	public String getOrder_date() {
		return Order_date;
	}

	public void setOrder_date (String Order_date) {
		this.Order_date = Order_date;
	}
	
	

}