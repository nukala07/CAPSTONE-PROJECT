package com.example.demo.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cart")
public class Cart {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Cart_id;
	
	@Column(name = "Product_id")
    private int Product_id;

    @Column(name = "customer_id")
    private Long customer_id;
    
    @Column(name = "Quantity")
    private String Quantity;
    
    
    
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cart(int Cart_id, int product_id, Long customer_id, String Quantity) {
		super();
		this.Cart_id =Cart_id;
		this.Product_id = product_id;
		this.customer_id = customer_id;
		this.Quantity = Quantity;
		
	}

	public int Cart_id () {
		return Cart_id;
	}

	

	public int getProduct_id() {
		return Product_id;
	}

	public void setProduct_id(int Product_id) {
		this.Product_id = Product_id;
	}

	public long getcustomer_id() {
		return customer_id;
	}

	public void setcustomer_id(long customer_id) {
		this.customer_id =customer_id;
	
	}
	
	public String getQuantity() {
		return Quantity;
	}

	public void setQuantity (String Quantity) {
		this.Quantity =Quantity;
	}
	
	
	
}
