package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.modal.event;
import com.example.demo.repo.eventRepo;


@CrossOrigin(origins ="null", allowedHeaders = "*")
@RestController
@RequestMapping("/pmt")
public class eventcontroller {
	
	@Autowired
	private eventRepo eventRepo;
	
	 @PostMapping("/event")
	    public event createevent(@RequestBody event event) {
		 return eventRepo.save(event);
	    }

}
