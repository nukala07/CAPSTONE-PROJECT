package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.modal.event;



public interface eventRepo extends JpaRepository<event, String>{

}


