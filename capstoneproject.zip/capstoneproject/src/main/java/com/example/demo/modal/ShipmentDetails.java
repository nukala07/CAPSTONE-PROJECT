package com.example.demo.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="ShipmentDetails")
public class ShipmentDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int shipment_id;

	@Column(name ="shipment_date")
	private String shipment_date;

	@Column(name ="Order_id")
	private String Order_id;

	@Column(name ="user_id")
	private int user_id;
	
	


	public ShipmentDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public ShipmentDetails(int shipment_id, String shipment_date, String Order_id, int User_id, int user_id) {
		super();
		this.shipment_id = shipment_id;
		this.shipment_date = shipment_date;
		this.Order_id =  Order_id;
		this.user_id = user_id;
		
	}


	public int No_of_items() {
		return shipment_id;
	}

	

	public String getshipment_date() {
		return shipment_date;
	}

	public void setshipment_date(String shipment_date) {
		this.shipment_date = shipment_date;
	}

	public String getOrder_id() {
		return Order_id;
	}

	public void setOrder_id(String Order_id) {
		this.Order_id = Order_id;
	}

	public int getuser_id() {
		return user_id;
	}

	public void setuser_id(int user_id) {
		this.user_id = user_id;
	}
    
	
	
	
	

}
